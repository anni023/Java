/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package candy;

/**
 *
 * @author Tarique-PC
 */
public class CashRegister
{
    private int cashOnHand;
 
        //Default constructor
    public CashRegister()
    {
        cashOnHand = 500;
    }
 
        //Constructor with parameters
    public CashRegister(int cashIn)
    {
       if (cashIn >= 0)
       {
             cashOnHand = cashIn;
       }
       else
       {
          cashOnHand = 500;
        }
    }
 
        //current amount in the cash register
    public int currentBalance()
    {
         return cashOnHand;
    }
 
        //Recieves amount deposited
    public void acceptAmount(int amountIn)
    {
        if(amountIn <= 0)
        {
         throw new RuntimeException("The amount going into the register must be greater than zero.");
        }
        else
        {
            cashOnHand = cashOnHand + amountIn;
        }
    }
}